# Taller 2 — Tienda Virtual con Flask

![commits](https://badgen.net/github/commits/clubdecomputacion/lp2-taller2?icon=github)
![last\_commit](https://img.shields.io/github/last-commit/clubdecomputacion/lp2-taller2)

## Autor

* Early Andrés Erazo 

## Descripción del proyecto

Este proyecto consiste en el desarrollo de una tienda virtual sencilla utilizando Python, Flask, SQLite, Flask-SQLAlchemy y plantillas HTML con Jinja2.

La aplicación permite consultar un catálogo de productos tecnológicos, filtrar los productos por categoría, visualizar la información detallada de cada producto y consultar su disponibilidad según el estado y las unidades existentes en el inventario.

Los productos iniciales se encuentran definidos en un archivo JSON y se cargan en la base de datos SQLite mediante un comando de Flask.

## Funcionalidades

* Mostrar el catálogo de productos con sus imágenes, nombres, marcas y precios.
* Filtrar los productos por categoría.
* Consultar los detalles de un producto mediante su SKU.
* Mostrar las categorías registradas y la cantidad de productos asociados.
* Indicar si un producto está disponible o agotado.
* Crear las tablas de la base de datos mediante un comando de Flask.
* Cargar los productos desde un archivo JSON sin duplicarlos por SKU.

## Tecnologías utilizadas

* Python
* Flask
* Flask-SQLAlchemy
* SQLite
* HTML
* Jinja2
* JSON
* Git y GitHub

## Estructura del proyecto

```text
lp2-taller2/
├── app/
│   ├── data/
│   │   └── productos.json
│   ├── static/
│   │   └── images/
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── detalle.html
│   │   └── categorias.html
│   ├── __init__.py
│   ├── commands.py
│   ├── extensions.py
│   ├── models.py
│   └── routes.py
├── docs/
│   └── GUIA.md
├── instance/
├── config.py
├── main.py
├── requirements.txt
└── run.py
```

## Instalación y ejecución

### 1. Clonar el repositorio

```bash
git clone https://github.com/clubdecomputacion/lp2-taller2.git
cd lp2-taller2
```

### 2. Crear y activar el entorno virtual

En Ubuntu o WSL:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Instalar las dependencias

```bash
pip install -r requirements.txt
```

### 4. Crear las tablas de la base de datos

```bash
flask --app run:app init-db
```

### 5. Cargar los productos

```bash
flask --app run:app seed-db
```

El comando carga los productos que todavía no existen según su SKU.

### 6. Ejecutar la aplicación

```bash
flask --app run:app run --debug
```

Abrir en el navegador:

http://127.0.0.1:5000

## Rutas principales

| Ruta             | Descripción                     |
| ---------------- | ------------------------------- |
| `/`              | Catálogo de productos           |
| `/?categoria=ID` | Catálogo filtrado por categoría |
| `/producto/SKU`  | Detalle de un producto          |
| `/categorias`    | Listado de categorías           |

## Base de datos

La aplicación utiliza SQLite y Flask-SQLAlchemy para administrar dos entidades principales:

* **Categoria:** almacena las categorías de los productos.
* **Producto:** almacena el SKU, la marca, el nombre, el precio, la imagen, el stock, el estado y la categoría asociada.

La relación entre ambas entidades se establece mediante la clave foránea `categoria_id` en la tabla de productos.

## Pruebas realizadas

* Visualización del catálogo y las imágenes.
* Filtrado de productos por categoría.
* Consulta del detalle de un producto.
* Visualización de las categorías.
* Identificación de productos sin stock.

## Documentación

Consulta la guía del proyecto en [`docs/GUIA.md`](docs/GUIA.md).


